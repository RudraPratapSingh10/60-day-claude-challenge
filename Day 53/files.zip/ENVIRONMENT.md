# Environment Reference — Road Accident Insight Explorer

**Status:** Reflects the exact Day 3 working environment.

## Tools and versions

| Tool | Version |
|---|---|
| Python | 3.13.0 |
| pip | 26.2 |
| Git | 2.47.1.windows.2 |
| VS Code | 1.131.0 |
| Streamlit | 1.60.0 |
| pandas | 2.2.3 (pinned — see `SETUP.md` known issues) |
| plotly | 6.9.0 |

Full pinned dependency list lives in `requirements.txt` at the project root — that file is the actual source of truth for exact versions; this table is a human-readable summary.

## Environment variables

**None required for local development or deployment.** This app has no API keys, no database credentials, and no secrets of any kind — a direct consequence of the Day 2 architecture decision to use no external APIs, no LLM calls, and no database server.

If this ever changes (e.g., a future scope item adds a real-time data feed requiring an API key), it would be documented here and stored using Streamlit's `secrets.toml` mechanism (never committed to Git) — but this doesn't apply to v1.0.

## Configuration files

| File | Purpose |
|---|---|
| `src/config.py` | Centralizes shared constants: dataset file paths, app title. Created Day 3 so every module (`app.py`, and tomorrow's `data_cleaning.py`/`insights.py`) references one source of truth instead of hardcoding paths independently. |
| `requirements.txt` | Exact pinned dependency versions, generated via `pip freeze`. Regenerate with `python -m pip freeze > requirements.txt` after installing any new package. |
| `.gitignore` | Excludes `venv/`, `__pycache__/`, and other local-only files from version control (Python template, set up Day 2). |

## Local vs. deployed environment

| Aspect | Local (your machine) | Deployed (Streamlit Community Cloud, Day 9) |
|---|---|---|
| Python version | 3.13.0 | Streamlit Cloud selects automatically, or reads a `runtime.txt` if we add one later |
| Dependencies | Installed manually via `requirements.txt` | Installed automatically from the same `requirements.txt` on deploy |
| Raw dataset | Downloaded manually, placed in `data/raw/` (not committed) | The **cleaned** Parquet file (`data/processed/`) will be committed instead — the raw CSV never needs to ship to production, only the cleaned output (Day 4 decision point) |
| Secrets | None needed | None needed |

## Known environment quirks (Windows-specific, discovered Day 3)

- `pip` cannot always be run directly as `pip <command>` in Git Bash on Windows due to a permissions/file-type issue with how the launcher is registered. Workaround: always use `python -m pip <command>`.
- `pandas` versions ≥3.0 (published very recently at time of writing) can be blocked by Windows' Application Control / Smart App Control security feature, since new compiled binaries haven't accumulated enough reputation yet. Workaround: pin to `pandas==2.2.3`, an established, widely-trusted release.
