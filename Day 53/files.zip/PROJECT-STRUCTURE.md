# Project Structure — Road Accident Insight Explorer

**Status:** Updated Day 3 to reflect the working foundation. Original Day 2 structure is preserved; additions are marked.

```
road-accident-explorer/
├── data/
│   ├── raw/
│   │   ├── .gitkeep
│   │   └── road_safety_accidents_2019.csv   ⭐ Day 3 — real dataset, NOT committed to Git (see .gitignore)
│   └── processed/
│       └── .gitkeep                          # will hold cleaned_accidents.parquet (Day 4)
├── src/
│   ├── config.py         ⭐ Day 3 — shared constants (file paths, app title)
│   ├── data_cleaning.py  # still empty — ETL logic comes Day 4
│   ├── insights.py       # still empty — insight logic comes Day 5
│   └── app.py            ⭐ Day 3 — minimal "Hello World" version; full UI comes Days 6-7
├── notebooks/
│   ├── .gitkeep
│   └── 01_data_exploration.py   ⭐ Day 3 — one-time exploratory script, confirmed dataset shape/quality
├── docs/
│   ├── ARCHITECTURE.md
│   ├── SCHEMA.md
│   ├── API.md
│   ├── UI-WIREFRAMES.md
│   ├── PROJECT-STRUCTURE.md   (this file)
│   ├── SETUP.md               ⭐ Day 3
│   ├── ENVIRONMENT.md         ⭐ Day 3
│   └── DAY3-SUMMARY.md        ⭐ Day 3
├── venv/                 ⭐ Day 3 — local virtual environment, NOT committed to Git (excluded via .gitignore)
├── requirements.txt      ⭐ Day 3 — filled in with pinned versions (was empty placeholder from Day 2)
├── README.md
└── .gitignore
```

## What changed since Day 2

- `src/config.py` is a new file, not originally listed in the Day 2 structure — added because centralizing file paths in one place became a clear need the moment a second file (`app.py`) needed to reference the dataset path. This is additive, not a deviation: it lives exactly where the Day 2 structure said application code would live (`src/`).
- `notebooks/01_data_exploration.py` is the first real file in what was an empty placeholder folder — used exactly as designed (Day 2 rationale: "scratch space... never imported by `src/`").
- `requirements.txt` and `src/app.py` are no longer empty placeholders — both now contain real, working content.
- `venv/` exists locally as expected, and is correctly git-ignored (standard practice — virtual environments are always machine-specific and never committed).
- The raw dataset CSV is intentionally **not committed to Git** — it's a ~15MB file that any developer can re-download from the documented Kaggle source (see `SETUP.md`); committing large data files bloats repository size unnecessarily. Only the *cleaned, processed* Parquet file (created Day 4) will be committed, since that's the smaller, final artifact the deployed app actually needs.

## Confirmation against Day 2 design

No structural deviation from the approved `PROJECT-STRUCTURE.md`. All additions are exactly where Day 2 said they'd go.
