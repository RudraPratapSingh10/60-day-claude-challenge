# Setup Guide — Road Accident Insight Explorer

**Status:** Reflects the exact working setup confirmed on Day 3. Anyone (including a fresh AI session or a new collaborator) can follow this to get the project running from scratch.

## Prerequisites

| Tool | Version used | Why it's needed |
|---|---|---|
| Python | 3.13.0 | The language the entire app is written in |
| pip | 26.2 (bundled with Python) | Installs Python libraries |
| VS Code | 1.131.0 | Code editor (any editor works, but this is what we used) |
| VS Code Python extension | Microsoft, stable release (not pre-release) | Python syntax support, debugging, interpreter detection |
| VS Code Pylance extension | Microsoft | Autocomplete and error-checking |
| Git | 2.47.1 | Version control, already set up on Day 2 |

## Step-by-step setup (from a fresh clone)

1. Clone the repository:
   ```
   git clone https://github.com/RudraPratapSingh10/road-accident-explorer.git
   cd road-accident-explorer
   ```

2. Create a virtual environment (isolates this project's dependencies from your system Python):
   ```
   python -m venv venv
   ```

3. Activate it:
   - **Windows PowerShell:**
     ```
     .\venv\Scripts\Activate.ps1
     ```
     If you see an "execution of scripts is disabled" error:
     ```
     Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
     ```
   - **Mac/Linux:**
     ```
     source venv/bin/activate
     ```
   You'll know it worked when your terminal prompt starts with `(venv)`.

4. Install dependencies:
   ```
   python -m pip install --upgrade pip
   python -m pip install -r requirements.txt
   ```

   > ⚠️ **Known issue:** `pandas` versions ≥3.0 can trigger a Windows "Application Control policy" DLL block on some machines (very new binaries haven't built up OS trust yet). This project pins `pandas==2.2.3` specifically to avoid that — don't upgrade pandas without testing on Windows first.

5. Place the dataset: download **"Road Safety Data — Accidents 2019"** from Kaggle (`kaggle.com/datasets/mostafafaramin/road-safety-data-accidents-2019`), extract it, and place the CSV at:
   ```
   data/raw/road_safety_accidents_2019.csv
   ```
   (Not committed to Git — see `.gitignore` — each developer downloads their own copy.)

6. Run the app:
   ```
   streamlit run src/app.py
   ```

7. Open `http://localhost:8501` in your browser (usually opens automatically).

## Verifying it worked

You should see:
- Page title: "Road Accident Insight Explorer"
- A green success message: "Dataset loaded successfully: 117,536 rows, 32 columns"
- A preview table of the first 10 rows

## Common issues and fixes (encountered during Day 3 setup)

| Symptom | Cause | Fix |
|---|---|---|
| `bash: pip: Permission denied` | Git Bash can't execute pip's launcher directly on some Windows setups | Use `python -m pip ...` instead of bare `pip ...` |
| `ImportError: DLL load failed ... Application Control policy has blocked this file` | Very new pandas binary not yet trusted by Windows security | Use `pandas==2.2.3` (pinned in `requirements.txt`) instead of the latest release |
| `FileNotFoundError` on the CSV path | Windows silently appended a duplicate `.csv` extension when renaming with "hide extensions" on | Check the real filename with `dir`; rename to remove any duplicate extension |
| `ModuleNotFoundError: No module named 'pandas'` after a reinstall | A typo in the install command (`python -m install ...` instead of `python -m pip install ...`) silently failed | Always double check `pip` appears in the command |
| `IndentationError` on a freshly created `.py` file | Editor auto-indent added leading whitespace before the first line | Select all, delete, and repaste the file content flush to the left margin |
