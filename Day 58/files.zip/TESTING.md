# Testing Log — Road Accident Insight Explorer

**Date:** August 6, 2026
**Phase:** Testing, Debugging & Production Optimization (Day 8)

## Senior review methodology

Before manual testing, the codebase (`app.py`, `analytics.py`, `insights.py`, `data_cleaning.py`) was reviewed as a QA Engineer / Security Reviewer / Performance Engineer would: checking for broken functionality, edge cases, error handling gaps, security risks, and performance bottlenecks, prior to any live click-through testing.

## Bugs found and fixed

### 🔴 Bug 1 (Critical) — "Reset all filters" did not reset anything
- **Found via:** code review (not manual testing) — inspecting the button's `on_click` behavior
- **Root cause:** the button called `st.rerun()` without clearing widget state. Streamlit widgets persist their last-selected value across reruns automatically; without explicit `key`s and `st.session_state` clearing, the button was a no-op that looked functional but did nothing.
- **Fix:** added explicit `key=` to every filter widget and an `on_click=_reset_filters` handler that deletes each key from `st.session_state`, forcing widgets back to their defaults.
- **Verified:** manually tested — applied Severity + Region + Weather filters, clicked Reset, confirmed all three dropdowns visually cleared and metrics returned to the full 117,508 / 100% dataset view.

### 🟡 Bug 2 (Moderate) — Unreliable map color scale
- **Found via:** code review
- **Root cause:** `range_color` was calculated from `groupby(["latitude","longitude"]).size().max()` — exact coordinate duplicates, which are rare (usually 1-2), making the heat scale nearly meaningless for smaller filtered selections.
- **Fix:** removed the manual `range_color` override, letting Plotly's `density_mapbox` compute its own density-based color scale automatically.
- **Verified:** manually tested across multiple filter combinations — heat gradient renders sensibly at both large (full dataset) and small (single-severity) selection sizes.

### 🔴 Bug 3 (Critical) — Region filter showed numeric codes, not names
- **Found via:** manual testing (user applying filters and reviewing the resulting chips)
- **Root cause:** the raw dataset's `Local_Authority_(District)` field is a DfT-specific numeric code, not a text district name. Day 4's cleaning script incorrectly assumed it was already human-readable and passed it through unchanged.
- **Fix:** sourced the UK Department for Transport's official "Road Safety Open Data Guide" (free, public, OGL-licensed), extracted the Local Authority District code-to-name lookup table (532 codes), and updated `data_cleaning.py` to decode `region_code` into a real `region` name during cleaning — same pattern as the existing severity/weather/road-type decoding.
- **Verified:** re-ran the full cleaning pipeline (117,536 → 117,508 rows, unchanged), confirmed zero missing `region` values, and visually confirmed real district names (Westminster, Camden, Lambeth, Brent, Lincoln, Liverpool, etc.) appear correctly in the live app's Region filter dropdown.

## Manual test checklist (executed)

| Test | Result |
|---|---|
| No filters applied — full dataset loads | ✅ Pass |
| Single filter (Severity) | ✅ Pass — matches Day 5's tested value (1,658 for Fatal) |
| Multiple filters combined (Region + Severity + Weather + Date range) | ✅ Pass |
| Reset all filters after applying several | ✅ Pass (after fix) |
| Region filter shows real, readable names | ✅ Pass (after fix) |
| Hotspot map updates with filters | ✅ Pass |
| Insights panel updates with filters | ✅ Pass |
| Metrics row stays in sync with active filters | ✅ Pass |
| App recovers from a stale/duplicate background process | ✅ Confirmed root cause of an earlier false alarm; not an app bug |

## Known non-issues (reviewed, no action needed)

- `accident_id` displays in scientific notation in raw terminal/DataFrame previews — cosmetic only, underlying value is correctly stored as a string; does not affect the app UI.
- Region multiselect has 500+ options — usable via search-as-you-type, not a blocker for v1.0.
- No explicit `alt` text on Plotly charts — inherent library limitation; color contrast and font sizing otherwise meet NFR-6.

## Security review summary

No SQL/eval/unsafe code paths. `unsafe_allow_html=True` renders only static, developer-authored CSS — no user input reaches it. No API keys, secrets, or credentials anywhere in the app. Appropriate risk profile for a public, read-only data dashboard.

## Release readiness

All planned v1.0 features (FR-1 through FR-8) are implemented, tested, and working. Three real bugs found and fixed today. No known blocking issues remain. Ready for Day 9 deployment.
